---
name: Feature
about: If you want to propose a new feature or enhancement
labels: kind/feature
---

<!--

Feel free to ask questions in #prometheus-operator on Kubernetes Slack!

-->

**What is missing?**

**Why do we need it?**

**Environment**

* kube-prometheus version:

    `Insert Git SHA here`

**Anything else we need to know?**:
